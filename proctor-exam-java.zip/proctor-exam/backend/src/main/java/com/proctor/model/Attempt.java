package com.proctor.model;
import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.*;
import lombok.*;
@Entity @Getter @Setter
@Table(uniqueConstraints = @UniqueConstraint(columnNames = {"examId", "studentId"}))
public class Attempt {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
  private Long examId;
  private Long studentId;
  private LocalDateTime startTime;
  private LocalDateTime submitTime;
  private int score;
  private String status; // IN_PROGRESS, SUBMITTED
  @ElementCollection(fetch = FetchType.EAGER) private Map<Long, Integer> answers = new HashMap<>();
}
