package com.proctor.model;
public enum Role { STUDENT, TEACHER, ADMIN }
