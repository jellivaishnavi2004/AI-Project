package com.proctor.controller;
import com.proctor.model.*;
import com.proctor.repo.*;
import com.proctor.service.FaceDetectionService;
import java.util.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;
@RestController @RequestMapping("/proctor") @RequiredArgsConstructor
public class ProctorController {
  private static final Set<String> EVENTS = Set.of("TAB_SWITCH", "FULLSCREEN_EXIT", "COPY_PASTE");
  private final ProctorLogRepository logs; private final AttemptRepository attempts; private final FaceDetectionService faces;
  @PostMapping("/{attemptId}/event") @PreAuthorize("hasRole('STUDENT')")
  public void event(@PathVariable Long attemptId, @RequestParam String type, Authentication auth) {
    check(attemptId, auth);
    if (!EVENTS.contains(type)) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Unknown event");
    save(attemptId, type);
  }
  @PostMapping("/{attemptId}/frame") @PreAuthorize("hasRole('STUDENT')")
  public Map<String, Integer> frame(@PathVariable Long attemptId, @RequestParam("file") MultipartFile file, Authentication auth) throws Exception {
    check(attemptId, auth);
    int n;
    try { n = faces.countFaces(file.getBytes()); }
    catch (IllegalArgumentException e) { throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid image"); }
    if (n == 0) save(attemptId, "NO_FACE"); else if (n > 1) save(attemptId, "MULTIPLE_FACES");
    return Map.of("faces", n);
  }
  @GetMapping("/{attemptId}/logs") @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
  public Map<String, Object> report(@PathVariable Long attemptId) {
    List<ProctorLog> l = logs.findByAttemptIdOrderByTimestamp(attemptId);
    String risk = l.size() >= 6 ? "HIGH" : l.size() >= 2 ? "MEDIUM" : "LOW"; // simple threshold-based risk score
    return Map.of("violations", l.size(), "risk", risk, "logs", l);
  }
  private void save(Long id, String type) { ProctorLog p = new ProctorLog(); p.setAttemptId(id); p.setType(type); logs.save(p); }
  private void check(Long id, Authentication auth) {
    Attempt a = attempts.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    if (!a.getStudentId().equals(auth.getPrincipal())) throw new ResponseStatusException(HttpStatus.FORBIDDEN);
  }
}
