package com.proctor.controller;
import com.proctor.model.*;
import com.proctor.repo.*;
import java.time.LocalDateTime;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
@RestController @RequestMapping("/attempts") @RequiredArgsConstructor @PreAuthorize("hasRole('STUDENT')")
public class AttemptController {
  private final AttemptRepository attempts; private final ExamRepository exams;
  @PostMapping("/start/{examId}")
  public Attempt start(@PathVariable Long examId, Authentication auth) {
    Long uid = (Long) auth.getPrincipal();
    exams.findById(examId).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    if (attempts.findByExamIdAndStudentId(examId, uid).isPresent()) throw new ResponseStatusException(HttpStatus.CONFLICT, "Already attempted");
    Attempt a = new Attempt(); a.setExamId(examId); a.setStudentId(uid); a.setStartTime(LocalDateTime.now()); a.setStatus("IN_PROGRESS");
    return attempts.save(a);
  }
  @PutMapping("/{id}/answer") @Transactional
  public void answer(@PathVariable Long id, @RequestParam Long questionId, @RequestParam int option, Authentication auth) {
    Attempt a = own(id, auth);
    if (!"IN_PROGRESS".equals(a.getStatus()) || expired(a)) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Exam closed");
    a.getAnswers().put(questionId, option); attempts.save(a);
  }
  @PostMapping("/{id}/submit") @Transactional
  public Attempt submit(@PathVariable Long id, Authentication auth) {
    Attempt a = own(id, auth);
    if (!"IN_PROGRESS".equals(a.getStatus())) throw new ResponseStatusException(HttpStatus.CONFLICT, "Already submitted");
    int score = 0;
    for (Question q : exams.findById(a.getExamId()).get().getQuestions())
      if (Integer.valueOf(q.getCorrectIndex()).equals(a.getAnswers().get(q.getId()))) score += q.getMarks();
    a.setScore(score); a.setSubmitTime(LocalDateTime.now()); a.setStatus("SUBMITTED");
    return attempts.save(a);
  }
  private Attempt own(Long id, Authentication auth) {
    Attempt a = attempts.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    if (!a.getStudentId().equals(auth.getPrincipal())) throw new ResponseStatusException(HttpStatus.FORBIDDEN);
    return a;
  }
  private boolean expired(Attempt a) { // timer is enforced on the server, never trusted from the browser
    int mins = exams.findById(a.getExamId()).get().getDurationMinutes();
    return LocalDateTime.now().isAfter(a.getStartTime().plusMinutes(mins));
  }
}
