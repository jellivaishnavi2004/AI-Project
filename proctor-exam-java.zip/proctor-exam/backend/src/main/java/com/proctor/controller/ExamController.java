package com.proctor.controller;
import com.proctor.model.Exam;
import com.proctor.repo.ExamRepository;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/exams") @RequiredArgsConstructor
public class ExamController {
  private final ExamRepository exams;
  @PostMapping @PreAuthorize("hasRole('TEACHER')")
  public Exam create(@RequestBody Exam e, Authentication auth) {
    e.setCreatedBy((Long) auth.getPrincipal());
    e.getQuestions().forEach(q -> q.setExam(e));
    return exams.save(e);
  }
  @GetMapping public List<Exam> list() { return exams.findAll(); }
}
