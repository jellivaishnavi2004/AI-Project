package com.proctor.repo;
import com.proctor.model.ProctorLog;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ProctorLogRepository extends JpaRepository<ProctorLog, Long> { List<ProctorLog> findByAttemptIdOrderByTimestamp(Long attemptId); }
