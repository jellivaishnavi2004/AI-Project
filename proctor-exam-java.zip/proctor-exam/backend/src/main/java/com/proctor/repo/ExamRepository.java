package com.proctor.repo;
import com.proctor.model.Exam;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ExamRepository extends JpaRepository<Exam, Long> {}
