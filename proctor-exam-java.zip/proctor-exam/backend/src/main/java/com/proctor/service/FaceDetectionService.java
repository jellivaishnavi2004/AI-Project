package com.proctor.service;
import jakarta.annotation.PostConstruct;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.*;
import nu.pattern.OpenCV;
import org.opencv.core.*;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.objdetect.CascadeClassifier;
import org.springframework.stereotype.Service;
@Service
public class FaceDetectionService {
  private CascadeClassifier cascade;
  @PostConstruct
  void init() throws IOException {
    OpenCV.loadLocally(); // loads the native OpenCV library bundled in the jar
    Path tmp = Files.createTempFile("cascade", ".xml");
    try (InputStream in = getClass().getResourceAsStream("/haarcascade_frontalface_default.xml")) {
      Files.copy(in, tmp, StandardCopyOption.REPLACE_EXISTING);
    }
    cascade = new CascadeClassifier(tmp.toString());
  }
  public synchronized int countFaces(byte[] jpg) {
    Mat img = Imgcodecs.imdecode(new MatOfByte(jpg), Imgcodecs.IMREAD_GRAYSCALE);
    if (img.empty()) throw new IllegalArgumentException("Invalid image");
    MatOfRect faces = new MatOfRect();
    cascade.detectMultiScale(img, faces, 1.1, 5, 0, new Size(60, 60), new Size());
    return faces.toArray().length;
  }
}
