package com.proctor;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class ProctorApplication { public static void main(String[] a) { SpringApplication.run(ProctorApplication.class, a); } }
