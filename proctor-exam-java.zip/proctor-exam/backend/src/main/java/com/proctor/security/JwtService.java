package com.proctor.security;
import com.proctor.model.User;
import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import java.util.Date;
import javax.crypto.SecretKey;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
@Service
public class JwtService {
  @Value("${jwt.secret}") private String secret;
  private SecretKey key() { return Keys.hmacShaKeyFor(secret.getBytes()); }
  public String generate(User u) {
    return Jwts.builder().subject(String.valueOf(u.getId())).claim("role", u.getRole().name())
      .expiration(new Date(System.currentTimeMillis() + 86_400_000)).signWith(key()).compact();
  }
  public Claims parse(String token) { return Jwts.parser().verifyWith(key()).build().parseSignedClaims(token).getPayload(); }
}
