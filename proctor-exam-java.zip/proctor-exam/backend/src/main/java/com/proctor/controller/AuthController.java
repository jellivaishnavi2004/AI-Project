package com.proctor.controller;
import com.proctor.model.*;
import com.proctor.repo.UserRepository;
import com.proctor.security.JwtService;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
@RestController @RequestMapping("/auth") @RequiredArgsConstructor
public class AuthController {
  record RegisterReq(String name, String email, String password, Role role) {}
  record LoginReq(String email, String password) {}
  private final UserRepository users; private final PasswordEncoder encoder; private final JwtService jwt;
  @PostMapping("/register")
  public Map<String, Object> register(@RequestBody RegisterReq r) {
    if (users.findByEmail(r.email()).isPresent()) throw new ResponseStatusException(HttpStatus.CONFLICT, "Email exists");
    User u = new User(); u.setName(r.name()); u.setEmail(r.email()); u.setPassword(encoder.encode(r.password()));
    u.setRole(r.role() == Role.TEACHER ? Role.TEACHER : Role.STUDENT); // no self-signup as ADMIN
    users.save(u); return Map.of("id", u.getId(), "role", u.getRole());
  }
  @PostMapping("/login")
  public Map<String, Object> login(@RequestBody LoginReq r) {
    User u = users.findByEmail(r.email()).filter(x -> encoder.matches(r.password(), x.getPassword()))
      .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Bad credentials"));
    return Map.of("token", jwt.generate(u), "role", u.getRole());
  }
}
