package com.proctor.model;
import com.fasterxml.jackson.annotation.*;
import jakarta.persistence.*;
import java.util.*;
import lombok.*;
@Entity @Getter @Setter
public class Question {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
  @Column(name = "question_text") private String text;
  @ElementCollection private List<String> options = new ArrayList<>();
  @JsonProperty(access = JsonProperty.Access.WRITE_ONLY) private int correctIndex; // never sent to students
  private int marks;
  @ManyToOne @JsonIgnore private Exam exam;
}
