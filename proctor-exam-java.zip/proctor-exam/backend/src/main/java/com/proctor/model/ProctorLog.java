package com.proctor.model;
import jakarta.persistence.*;
import java.time.LocalDateTime;
import lombok.*;
@Entity @Getter @Setter
public class ProctorLog {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
  private Long attemptId;
  private String type; // TAB_SWITCH, FULLSCREEN_EXIT, COPY_PASTE, NO_FACE, MULTIPLE_FACES
  private LocalDateTime timestamp = LocalDateTime.now();
}
