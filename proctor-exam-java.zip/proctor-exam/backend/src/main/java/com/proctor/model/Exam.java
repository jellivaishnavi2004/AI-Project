package com.proctor.model;
import jakarta.persistence.*;
import java.util.*;
import lombok.*;
@Entity @Getter @Setter
public class Exam {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
  private String title;
  private int durationMinutes;
  private Long createdBy;
  @OneToMany(mappedBy = "exam", cascade = CascadeType.ALL) private List<Question> questions = new ArrayList<>();
}
