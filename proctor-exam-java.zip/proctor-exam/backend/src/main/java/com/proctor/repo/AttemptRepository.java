package com.proctor.repo;
import com.proctor.model.Attempt;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
public interface AttemptRepository extends JpaRepository<Attempt, Long> { Optional<Attempt> findByExamIdAndStudentId(Long examId, Long studentId); }
