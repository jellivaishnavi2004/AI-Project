# ProctorExam: Online Exam Platform with AI Proctoring

Stack: Java 17, Spring Boot 3, Spring Security + JWT, MySQL, OpenCV (Java), Docker.

## Run
    docker compose up --build
Backend: http://localhost:8080

## API
| Method | Endpoint | Role |
|---|---|---|
| POST | /auth/register, /auth/login | public |
| POST/GET | /exams | TEACHER / any |
| POST | /attempts/start/{examId} | STUDENT |
| PUT | /attempts/{id}/answer?questionId=&option= | STUDENT |
| POST | /attempts/{id}/submit | STUDENT |
| POST | /proctor/{id}/event?type=TAB_SWITCH | STUDENT |
| POST | /proctor/{id}/frame (multipart "file") | STUDENT |
| GET | /proctor/{id}/logs | TEACHER/ADMIN |

## Design notes
- Server-side timer, one attempt per student (unique constraint), correct answers never sent to students.
- Risk score: 0-1 violations LOW, 2-5 MEDIUM, 6+ HIGH.

## Run without Docker
Start MySQL, then in `backend/` run `mvn spring-boot:run`. Face detection runs inside Spring Boot (OpenCV Java), no Python needed.
